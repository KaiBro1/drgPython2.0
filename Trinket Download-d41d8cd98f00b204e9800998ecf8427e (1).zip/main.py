print ('Dice Roll Game')

from random import randint
import time 

maxnumber = int(input('How many sides do you want on your dice?'))
 

def drg(maxnumber):
  
  print (randint(1,int(maxnumber)))

   
drg (maxnumber)
